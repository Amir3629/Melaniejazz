import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Booking Successful | Melanie Becker Vocal Coaching',
  description: 'Your booking request has been successfully submitted.',
} 